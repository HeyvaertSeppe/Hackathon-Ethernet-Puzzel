/* ========================================
 * Ethernet Puzzel - PSoC 4200M
 * STATUS: FIXED SCOPE ERRORS
 * Functies: High Power LED, Startup Flicker, Ghosting Fix, Full Feedback
 * ======================================== */

extern "C" {
#include "project.h"
#include <stdio.h>
#include <string.h>

    int _write(int file, char *ptr, int len) {
        for (int i = 0; i < len; i++) UART_UartPutChar(ptr[i]);
        return len;
    }
}

/* ========== ALLE VARIABELEN (Bovenaan voor scope) ========== */
volatile uint32_t ms_teller = 0u;
extern "C" CY_ISR(SysTick_Handler) {
    ms_teller++;
}

enum SpelStatus { WACHTEN, SPELEN, OPGELOST, KLAAR };
static SpelStatus huidigeStatus = WACHTEN;

// Puzzel data
static int doel[5];           
static int laatsteStatus[5];  
static uint32_t startT = 0;
static uint32_t winT = 0;
static uint32_t lcdT = 0;
static uint32_t ademT = 0;

// LED data
static int ademIndex = 0;
#define MAX_POWER 600    
#define ADEM_STAPPEN 128 

const int adem_tabel[ADEM_STAPPEN] = {
    0, 1, 2, 4, 7, 11, 16, 21, 27, 34, 42, 51, 60, 71, 82, 94,
    107, 120, 134, 149, 164, 180, 197, 214, 231, 249, 267, 286, 305, 324, 344, 364,
    384, 404, 424, 444, 464, 483, 502, 521, 538, 555, 571, 586, 600, 613, 625, 636,
    646, 654, 661, 667, 672, 675, 677, 678, 678, 677, 675, 672, 667, 661, 654, 646,
    636, 625, 613, 600, 586, 571, 555, 538, 521, 502, 483, 464, 444, 424, 404, 384,
    364, 344, 324, 305, 286, 267, 249, 231, 214, 197, 180, 164, 149, 134, 120, 107,
    94, 82, 71, 60, 51, 42, 33, 26, 20, 15, 10, 7, 4, 2, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
};

/* ========== LED & LCD FUNCTIES ========== */
void led_rood_adem(int stap) {
    PWM_Blauw_WriteCompare(0);
    int val = (adem_tabel[stap % ADEM_STAPPEN] * MAX_POWER) / 678; 
    PWM_Rood_WriteCompare(val);
}

void led_blauw_fel() {
    PWM_Rood_WriteCompare(0);
    PWM_Blauw_WriteCompare(MAX_POWER);
}

void led_uit() {
    PWM_Rood_WriteCompare(0);
    PWM_Blauw_WriteCompare(0);
}

#define LCD_ADDR 0x27u
void lcd_stuur(uint8_t d, uint8_t rs) {
    uint8_t bl = 0x08;
    uint8_t h = (d & 0xF0) | rs | bl;
    uint8_t l = ((d << 4) & 0xF0) | rs | bl;
    uint8_t b[4] = { (uint8_t)(h|0x04), h, (uint8_t)(l|0x04), l };
    I2C_1_I2CMasterWriteBuf(LCD_ADDR, b, 4, I2C_1_I2C_MODE_COMPLETE_XFER);
    while (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_XFER_INP);
}

void lcd_init() {
    CyDelay(100);
    lcd_stuur(0x33,0); lcd_stuur(0x32,0); lcd_stuur(0x28,0);
    lcd_stuur(0x0C,0); lcd_stuur(0x06,0); lcd_stuur(0x01,0);
}

void lcd_print_gecentreerd(uint8_t rij, const char *tekst) {
    uint8_t rijen[] = {0x80, 0xC0, 0x94, 0xD4};
    uint8_t lengte = strlen(tekst);
    if (lengte > 20) lengte = 20;
    uint8_t spatiesLinks = (20 - lengte) / 2;
    uint8_t spatiesRechts = 20 - lengte - spatiesLinks;
    lcd_stuur(rijen[rij % 4], 0); 
    for (uint8_t i = 0; i < spatiesLinks; i++) lcd_stuur(' ', 1);
    for (uint8_t i = 0; i < lengte; i++) lcd_stuur(tekst[i], 1);
    for (uint8_t i = 0; i < spatiesRechts; i++) lcd_stuur(' ', 1);
}

/* ========== PUZZEL LOGICA ========== */
static int leesModulePin(int n) {
    uint8_t w = 0xFF;
    if(n==0) w=Module_0_Read(); if(n==1) w=Module_1_Read();
    if(n==2) w=Module_2_Read(); if(n==3) w=Module_3_Read();
    if(n==4) w=Module_4_Read();
    for (int j = 0; j < 5; j++) if (!(w & (1 << j))) return j;
    return -1;
}

void schudden() {
    static uint32_t seed = 0xACE1u;
    seed ^= ms_teller;
    bool ok = false;
    while (!ok) {
        for(int i=0; i<5; i++) doel[i] = i;
        for(int i=4; i>0; i--) {
            seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5;
            int j = seed % (i + 1);
            int t = doel[i]; doel[i] = doel[j]; doel[j] = t;
        }
        ok = true;
        for(int i=0; i<5; i++) if (leesModulePin(i) == doel[i]) ok = false;
    }
    printf("\r\n=== PUZZEL START ===\r\n");
    for(int i=0; i<5; i++) printf("Mod %d -> Plug %d\r\n", i, doel[i]);
}

/* ========== MAIN LOOP ========== */
int main(void) {
    CyGlobalIntEnable;
    CySysTickStart();
    CySysTickSetCallback(0u, SysTick_Handler);
    UART_Start();
    PWM_Rood_Start();
    PWM_Blauw_Start();
    
    LCD_VCC_Write(0);
    led_uit();

    for (;;) {
        uint32_t nu = ms_teller;

        if (huidigeStatus == WACHTEN) {
            if (Activate_Pin_Read()) {
                CyDelay(50);
                if (Activate_Pin_Read()) {
                    LCD_VCC_Write(1); 
                    CyDelay(500); 
                    I2C_1_Start();
                    lcd_init();
                    
                    // Startup Flicker
                    for(int i=0; i<3; i++) {
                        PWM_Rood_WriteCompare(MAX_POWER); PWM_Blauw_WriteCompare(0); CyDelay(200);
                        PWM_Rood_WriteCompare(0); PWM_Blauw_WriteCompare(MAX_POWER); CyDelay(200);
                        led_uit(); CyDelay(200);
                    }
                    
                    schudden();
                    for(int i=0; i<5; i++) laatsteStatus[i] = -2;
                    ademIndex = 0;
                    startT = ms_teller; 
                    huidigeStatus = SPELEN;
                }
            }
        } 
        
        else if (huidigeStatus == SPELEN) {
            if (nu - ademT > 20) { 
                led_rood_adem(ademIndex++);
                ademT = nu;
            }

            int goed = 0, vol = 0;
            for (int i = 0; i < 5; i++) {
                int p = leesModulePin(i);
                if (p != laatsteStatus[i]) {
                    if (p != -1) {
                        printf("Mod %d: Plug %d.", i, p);
                        if (p == doel[i]) printf(" CORRECT!\r\n");
                        else {
                            int w = -1;
                            for(int k=0; k<5; k++) if(doel[k] == p) w = k;
                            printf(" FOUT! (Naar Mod %d)\r\n", w);
                        }
                    } else printf("Mod %d: Plug verwijderd.\r\n", i);
                    laatsteStatus[i] = p;
                }
                if (p != -1) { vol++; if (p == doel[i]) goed++; }
            }

            if (goed == 5 && vol == 5) {
                huidigeStatus = OPGELOST; winT = nu; Done_Pin_Write(1);
            }

            if (nu - lcdT > 250) {
                lcdT = nu;
                uint32_t v = nu - startT;
                if (v < 20000) {
                    char b[21]; snprintf(b, 21, "Start over: %lu sec", (20000-v)/1000 + 1);
                    lcd_print_gecentreerd(3, b);
                    if (v < 10000) {
                        if ((v % 1000) < 500) {
                            lcd_print_gecentreerd(1, "Welkom bij de");
                            lcd_print_gecentreerd(2, "ethernet puzzel");
                        } else {
                            lcd_print_gecentreerd(1, ""); lcd_print_gecentreerd(2, "");
                        }
                    } else {
                        lcd_print_gecentreerd(1, "Welkom bij de");
                        lcd_print_gecentreerd(2, "ethernet puzzel");
                    }
                } else {
                    lcd_print_gecentreerd(3, ""); 
                    if (vol < 5) {
                        lcd_print_gecentreerd(1, "Steek alle plugs in");
                        lcd_print_gecentreerd(2, "de juiste volgorde");
                    } else {
                        char res[21]; snprintf(res, 21, "%d zijn correct", goed);
                        lcd_print_gecentreerd(1, res); lcd_print_gecentreerd(2, "probeer nog eens");
                    }
                }
            }
        }

        else if (huidigeStatus == OPGELOST) {
            led_blauw_fel();
            if (nu - lcdT > 500) {
                lcdT = nu;
                uint32_t wV = nu - winT;
                if (wV < 5000) {
                    lcd_print_gecentreerd(1, "ALLES JUIST!!!");
                    lcd_print_gecentreerd(2, "!!!!!!!!!!!!!!!!");
                } else if (wV < 25000) {
                    lcd_print_gecentreerd(1, "Ga nu naar de");
                    lcd_print_gecentreerd(2, "volgende puzzel");
                } else {
                    LCD_VCC_Write(0); led_uit(); huidigeStatus = KLAAR;
                }
            }
        }
    }
}