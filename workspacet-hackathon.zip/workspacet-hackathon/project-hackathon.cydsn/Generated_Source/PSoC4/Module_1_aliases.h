/*******************************************************************************
* File Name: Module_1.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Module_1_ALIASES_H) /* Pins Module_1_ALIASES_H */
#define CY_PINS_Module_1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Module_1_0			(Module_1__0__PC)
#define Module_1_0_PS		(Module_1__0__PS)
#define Module_1_0_PC		(Module_1__0__PC)
#define Module_1_0_DR		(Module_1__0__DR)
#define Module_1_0_SHIFT	(Module_1__0__SHIFT)
#define Module_1_0_INTR	((uint16)((uint16)0x0003u << (Module_1__0__SHIFT*2u)))

#define Module_1_1			(Module_1__1__PC)
#define Module_1_1_PS		(Module_1__1__PS)
#define Module_1_1_PC		(Module_1__1__PC)
#define Module_1_1_DR		(Module_1__1__DR)
#define Module_1_1_SHIFT	(Module_1__1__SHIFT)
#define Module_1_1_INTR	((uint16)((uint16)0x0003u << (Module_1__1__SHIFT*2u)))

#define Module_1_2			(Module_1__2__PC)
#define Module_1_2_PS		(Module_1__2__PS)
#define Module_1_2_PC		(Module_1__2__PC)
#define Module_1_2_DR		(Module_1__2__DR)
#define Module_1_2_SHIFT	(Module_1__2__SHIFT)
#define Module_1_2_INTR	((uint16)((uint16)0x0003u << (Module_1__2__SHIFT*2u)))

#define Module_1_3			(Module_1__3__PC)
#define Module_1_3_PS		(Module_1__3__PS)
#define Module_1_3_PC		(Module_1__3__PC)
#define Module_1_3_DR		(Module_1__3__DR)
#define Module_1_3_SHIFT	(Module_1__3__SHIFT)
#define Module_1_3_INTR	((uint16)((uint16)0x0003u << (Module_1__3__SHIFT*2u)))

#define Module_1_4			(Module_1__4__PC)
#define Module_1_4_PS		(Module_1__4__PS)
#define Module_1_4_PC		(Module_1__4__PC)
#define Module_1_4_DR		(Module_1__4__DR)
#define Module_1_4_SHIFT	(Module_1__4__SHIFT)
#define Module_1_4_INTR	((uint16)((uint16)0x0003u << (Module_1__4__SHIFT*2u)))

#define Module_1_INTR_ALL	 ((uint16)(Module_1_0_INTR| Module_1_1_INTR| Module_1_2_INTR| Module_1_3_INTR| Module_1_4_INTR))


#endif /* End Pins Module_1_ALIASES_H */


/* [] END OF FILE */
