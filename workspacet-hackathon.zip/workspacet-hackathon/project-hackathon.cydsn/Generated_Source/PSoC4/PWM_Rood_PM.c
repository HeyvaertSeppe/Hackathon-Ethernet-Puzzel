/*******************************************************************************
* File Name: PWM_Rood_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PWM_Rood.h"

static PWM_Rood_BACKUP_STRUCT PWM_Rood_backup;


/*******************************************************************************
* Function Name: PWM_Rood_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Rood_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: PWM_Rood_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Rood_Sleep(void)
{
    if(0u != (PWM_Rood_BLOCK_CONTROL_REG & PWM_Rood_MASK))
    {
        PWM_Rood_backup.enableState = 1u;
    }
    else
    {
        PWM_Rood_backup.enableState = 0u;
    }

    PWM_Rood_Stop();
    PWM_Rood_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_Rood_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Rood_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: PWM_Rood_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Rood_Wakeup(void)
{
    PWM_Rood_RestoreConfig();

    if(0u != PWM_Rood_backup.enableState)
    {
        PWM_Rood_Enable();
    }
}


/* [] END OF FILE */
