/*******************************************************************************
* File Name: PinOUT.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PinOUT_H) /* Pins PinOUT_H */
#define CY_PINS_PinOUT_H

#include "cytypes.h"
#include "cyfitter.h"
#include "PinOUT_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} PinOUT_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   PinOUT_Read(void);
void    PinOUT_Write(uint8 value);
uint8   PinOUT_ReadDataReg(void);
#if defined(PinOUT__PC) || (CY_PSOC4_4200L) 
    void    PinOUT_SetDriveMode(uint8 mode);
#endif
void    PinOUT_SetInterruptMode(uint16 position, uint16 mode);
uint8   PinOUT_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void PinOUT_Sleep(void); 
void PinOUT_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(PinOUT__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define PinOUT_DRIVE_MODE_BITS        (3)
    #define PinOUT_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - PinOUT_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the PinOUT_SetDriveMode() function.
         *  @{
         */
        #define PinOUT_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define PinOUT_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define PinOUT_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define PinOUT_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define PinOUT_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define PinOUT_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define PinOUT_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define PinOUT_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define PinOUT_MASK               PinOUT__MASK
#define PinOUT_SHIFT              PinOUT__SHIFT
#define PinOUT_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PinOUT_SetInterruptMode() function.
     *  @{
     */
        #define PinOUT_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define PinOUT_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define PinOUT_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define PinOUT_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(PinOUT__SIO)
    #define PinOUT_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(PinOUT__PC) && (CY_PSOC4_4200L)
    #define PinOUT_USBIO_ENABLE               ((uint32)0x80000000u)
    #define PinOUT_USBIO_DISABLE              ((uint32)(~PinOUT_USBIO_ENABLE))
    #define PinOUT_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define PinOUT_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define PinOUT_USBIO_ENTER_SLEEP          ((uint32)((1u << PinOUT_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << PinOUT_USBIO_SUSPEND_DEL_SHIFT)))
    #define PinOUT_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << PinOUT_USBIO_SUSPEND_SHIFT)))
    #define PinOUT_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << PinOUT_USBIO_SUSPEND_DEL_SHIFT)))
    #define PinOUT_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(PinOUT__PC)
    /* Port Configuration */
    #define PinOUT_PC                 (* (reg32 *) PinOUT__PC)
#endif
/* Pin State */
#define PinOUT_PS                     (* (reg32 *) PinOUT__PS)
/* Data Register */
#define PinOUT_DR                     (* (reg32 *) PinOUT__DR)
/* Input Buffer Disable Override */
#define PinOUT_INP_DIS                (* (reg32 *) PinOUT__PC2)

/* Interrupt configuration Registers */
#define PinOUT_INTCFG                 (* (reg32 *) PinOUT__INTCFG)
#define PinOUT_INTSTAT                (* (reg32 *) PinOUT__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define PinOUT_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(PinOUT__SIO)
    #define PinOUT_SIO_REG            (* (reg32 *) PinOUT__SIO)
#endif /* (PinOUT__SIO_CFG) */

/* USBIO registers */
#if !defined(PinOUT__PC) && (CY_PSOC4_4200L)
    #define PinOUT_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define PinOUT_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define PinOUT_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define PinOUT_DRIVE_MODE_SHIFT       (0x00u)
#define PinOUT_DRIVE_MODE_MASK        (0x07u << PinOUT_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins PinOUT_H */


/* [] END OF FILE */
