/*******************************************************************************
* File Name: Module_3.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Module_3_ALIASES_H) /* Pins Module_3_ALIASES_H */
#define CY_PINS_Module_3_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Module_3_0			(Module_3__0__PC)
#define Module_3_0_PS		(Module_3__0__PS)
#define Module_3_0_PC		(Module_3__0__PC)
#define Module_3_0_DR		(Module_3__0__DR)
#define Module_3_0_SHIFT	(Module_3__0__SHIFT)
#define Module_3_0_INTR	((uint16)((uint16)0x0003u << (Module_3__0__SHIFT*2u)))

#define Module_3_1			(Module_3__1__PC)
#define Module_3_1_PS		(Module_3__1__PS)
#define Module_3_1_PC		(Module_3__1__PC)
#define Module_3_1_DR		(Module_3__1__DR)
#define Module_3_1_SHIFT	(Module_3__1__SHIFT)
#define Module_3_1_INTR	((uint16)((uint16)0x0003u << (Module_3__1__SHIFT*2u)))

#define Module_3_2			(Module_3__2__PC)
#define Module_3_2_PS		(Module_3__2__PS)
#define Module_3_2_PC		(Module_3__2__PC)
#define Module_3_2_DR		(Module_3__2__DR)
#define Module_3_2_SHIFT	(Module_3__2__SHIFT)
#define Module_3_2_INTR	((uint16)((uint16)0x0003u << (Module_3__2__SHIFT*2u)))

#define Module_3_3			(Module_3__3__PC)
#define Module_3_3_PS		(Module_3__3__PS)
#define Module_3_3_PC		(Module_3__3__PC)
#define Module_3_3_DR		(Module_3__3__DR)
#define Module_3_3_SHIFT	(Module_3__3__SHIFT)
#define Module_3_3_INTR	((uint16)((uint16)0x0003u << (Module_3__3__SHIFT*2u)))

#define Module_3_4			(Module_3__4__PC)
#define Module_3_4_PS		(Module_3__4__PS)
#define Module_3_4_PC		(Module_3__4__PC)
#define Module_3_4_DR		(Module_3__4__DR)
#define Module_3_4_SHIFT	(Module_3__4__SHIFT)
#define Module_3_4_INTR	((uint16)((uint16)0x0003u << (Module_3__4__SHIFT*2u)))

#define Module_3_INTR_ALL	 ((uint16)(Module_3_0_INTR| Module_3_1_INTR| Module_3_2_INTR| Module_3_3_INTR| Module_3_4_INTR))


#endif /* End Pins Module_3_ALIASES_H */


/* [] END OF FILE */
