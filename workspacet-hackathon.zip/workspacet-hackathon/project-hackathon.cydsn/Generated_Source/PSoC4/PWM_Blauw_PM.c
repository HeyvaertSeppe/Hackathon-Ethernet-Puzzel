/*******************************************************************************
* File Name: PWM_Blauw_PM.c
* Version 2.10
*
* Description:
*  This file contains the setup, control, and status commands to support
*  the component operations in the low power mode.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "PWM_Blauw.h"

static PWM_Blauw_BACKUP_STRUCT PWM_Blauw_backup;


/*******************************************************************************
* Function Name: PWM_Blauw_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Blauw_SaveConfig(void)
{

}


/*******************************************************************************
* Function Name: PWM_Blauw_Sleep
********************************************************************************
*
* Summary:
*  Stops the component operation and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Blauw_Sleep(void)
{
    if(0u != (PWM_Blauw_BLOCK_CONTROL_REG & PWM_Blauw_MASK))
    {
        PWM_Blauw_backup.enableState = 1u;
    }
    else
    {
        PWM_Blauw_backup.enableState = 0u;
    }

    PWM_Blauw_Stop();
    PWM_Blauw_SaveConfig();
}


/*******************************************************************************
* Function Name: PWM_Blauw_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Blauw_RestoreConfig(void)
{

}


/*******************************************************************************
* Function Name: PWM_Blauw_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void PWM_Blauw_Wakeup(void)
{
    PWM_Blauw_RestoreConfig();

    if(0u != PWM_Blauw_backup.enableState)
    {
        PWM_Blauw_Enable();
    }
}


/* [] END OF FILE */
