/*******************************************************************************
* File Name: Module_0.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Module_0_ALIASES_H) /* Pins Module_0_ALIASES_H */
#define CY_PINS_Module_0_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Module_0_0			(Module_0__0__PC)
#define Module_0_0_PS		(Module_0__0__PS)
#define Module_0_0_PC		(Module_0__0__PC)
#define Module_0_0_DR		(Module_0__0__DR)
#define Module_0_0_SHIFT	(Module_0__0__SHIFT)
#define Module_0_0_INTR	((uint16)((uint16)0x0003u << (Module_0__0__SHIFT*2u)))

#define Module_0_1			(Module_0__1__PC)
#define Module_0_1_PS		(Module_0__1__PS)
#define Module_0_1_PC		(Module_0__1__PC)
#define Module_0_1_DR		(Module_0__1__DR)
#define Module_0_1_SHIFT	(Module_0__1__SHIFT)
#define Module_0_1_INTR	((uint16)((uint16)0x0003u << (Module_0__1__SHIFT*2u)))

#define Module_0_2			(Module_0__2__PC)
#define Module_0_2_PS		(Module_0__2__PS)
#define Module_0_2_PC		(Module_0__2__PC)
#define Module_0_2_DR		(Module_0__2__DR)
#define Module_0_2_SHIFT	(Module_0__2__SHIFT)
#define Module_0_2_INTR	((uint16)((uint16)0x0003u << (Module_0__2__SHIFT*2u)))

#define Module_0_3			(Module_0__3__PC)
#define Module_0_3_PS		(Module_0__3__PS)
#define Module_0_3_PC		(Module_0__3__PC)
#define Module_0_3_DR		(Module_0__3__DR)
#define Module_0_3_SHIFT	(Module_0__3__SHIFT)
#define Module_0_3_INTR	((uint16)((uint16)0x0003u << (Module_0__3__SHIFT*2u)))

#define Module_0_4			(Module_0__4__PC)
#define Module_0_4_PS		(Module_0__4__PS)
#define Module_0_4_PC		(Module_0__4__PC)
#define Module_0_4_DR		(Module_0__4__DR)
#define Module_0_4_SHIFT	(Module_0__4__SHIFT)
#define Module_0_4_INTR	((uint16)((uint16)0x0003u << (Module_0__4__SHIFT*2u)))

#define Module_0_INTR_ALL	 ((uint16)(Module_0_0_INTR| Module_0_1_INTR| Module_0_2_INTR| Module_0_3_INTR| Module_0_4_INTR))


#endif /* End Pins Module_0_ALIASES_H */


/* [] END OF FILE */
