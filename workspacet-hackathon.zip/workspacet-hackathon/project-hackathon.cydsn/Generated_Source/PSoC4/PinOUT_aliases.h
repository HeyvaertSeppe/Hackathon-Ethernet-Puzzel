/*******************************************************************************
* File Name: PinOUT.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PinOUT_ALIASES_H) /* Pins PinOUT_ALIASES_H */
#define CY_PINS_PinOUT_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define PinOUT_0			(PinOUT__0__PC)
#define PinOUT_0_PS		(PinOUT__0__PS)
#define PinOUT_0_PC		(PinOUT__0__PC)
#define PinOUT_0_DR		(PinOUT__0__DR)
#define PinOUT_0_SHIFT	(PinOUT__0__SHIFT)
#define PinOUT_0_INTR	((uint16)((uint16)0x0003u << (PinOUT__0__SHIFT*2u)))

#define PinOUT_INTR_ALL	 ((uint16)(PinOUT_0_INTR))


#endif /* End Pins PinOUT_ALIASES_H */


/* [] END OF FILE */
