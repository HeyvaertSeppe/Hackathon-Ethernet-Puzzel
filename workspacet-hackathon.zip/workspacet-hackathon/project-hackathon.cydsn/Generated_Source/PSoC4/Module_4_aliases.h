/*******************************************************************************
* File Name: Module_4.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Module_4_ALIASES_H) /* Pins Module_4_ALIASES_H */
#define CY_PINS_Module_4_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Module_4_0			(Module_4__0__PC)
#define Module_4_0_PS		(Module_4__0__PS)
#define Module_4_0_PC		(Module_4__0__PC)
#define Module_4_0_DR		(Module_4__0__DR)
#define Module_4_0_SHIFT	(Module_4__0__SHIFT)
#define Module_4_0_INTR	((uint16)((uint16)0x0003u << (Module_4__0__SHIFT*2u)))

#define Module_4_1			(Module_4__1__PC)
#define Module_4_1_PS		(Module_4__1__PS)
#define Module_4_1_PC		(Module_4__1__PC)
#define Module_4_1_DR		(Module_4__1__DR)
#define Module_4_1_SHIFT	(Module_4__1__SHIFT)
#define Module_4_1_INTR	((uint16)((uint16)0x0003u << (Module_4__1__SHIFT*2u)))

#define Module_4_2			(Module_4__2__PC)
#define Module_4_2_PS		(Module_4__2__PS)
#define Module_4_2_PC		(Module_4__2__PC)
#define Module_4_2_DR		(Module_4__2__DR)
#define Module_4_2_SHIFT	(Module_4__2__SHIFT)
#define Module_4_2_INTR	((uint16)((uint16)0x0003u << (Module_4__2__SHIFT*2u)))

#define Module_4_3			(Module_4__3__PC)
#define Module_4_3_PS		(Module_4__3__PS)
#define Module_4_3_PC		(Module_4__3__PC)
#define Module_4_3_DR		(Module_4__3__DR)
#define Module_4_3_SHIFT	(Module_4__3__SHIFT)
#define Module_4_3_INTR	((uint16)((uint16)0x0003u << (Module_4__3__SHIFT*2u)))

#define Module_4_4			(Module_4__4__PC)
#define Module_4_4_PS		(Module_4__4__PS)
#define Module_4_4_PC		(Module_4__4__PC)
#define Module_4_4_DR		(Module_4__4__DR)
#define Module_4_4_SHIFT	(Module_4__4__SHIFT)
#define Module_4_4_INTR	((uint16)((uint16)0x0003u << (Module_4__4__SHIFT*2u)))

#define Module_4_INTR_ALL	 ((uint16)(Module_4_0_INTR| Module_4_1_INTR| Module_4_2_INTR| Module_4_3_INTR| Module_4_4_INTR))


#endif /* End Pins Module_4_ALIASES_H */


/* [] END OF FILE */
