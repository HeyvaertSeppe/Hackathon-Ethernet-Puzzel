-- ======================================================================
-- project-hackathon.ctl generated from project-hackathon
-- 04/07/2026 at 15:55
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
