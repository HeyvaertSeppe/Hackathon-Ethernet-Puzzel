# Component constraints for C:\Users\Luc\Documents\PSoC Creator\MB_RTU_SLAVE\Design01.cydsn\TopDesign\workspacet-hackathon\project-hackathon.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\Luc\Documents\PSoC Creator\MB_RTU_SLAVE\Design01.cydsn\TopDesign\workspacet-hackathon\project-hackathon.cydsn\project-hackathon.cyprj
# Date: Tue, 07 Apr 2026 13:55:15 GMT
