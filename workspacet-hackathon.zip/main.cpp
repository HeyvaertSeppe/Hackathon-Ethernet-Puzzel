/* ========================================
 * Ethernet Puzzel - PSoC 4200M
 * ======================================== */

extern "C" {
#include "project.h"
#include <stdio.h>
#include <string.h>

    // Zorgt ervoor dat printf() via de UART naar PuTTY gaat
    int _write(int file, char *ptr, int len) {
        for (int i = 0; i < len; i++) {
            UART_UartPutChar(ptr[i]);
        }
        return len;
    }
}

// Milliseconde teller
volatile uint32_t millis_teller = 0u;

extern "C" CY_ISR(SysTick_Handler) {
    millis_teller++;
}

/* ========== LCD CONFIGURATIE ========== */
#define LCD_I2C_ADDR    0x27u
#define LCD_BACKLIGHT   0x08u
#define LCD_ENABLE      0x04u
#define LCD_RS          0x01u

static void lcd_i2c_schrijf_byte(uint8_t data) {
    static uint8_t i2c_buffer; 
    i2c_buffer = data | LCD_BACKLIGHT;
    I2C_1_I2CMasterWriteBuf(LCD_I2C_ADDR, &i2c_buffer, 1u, I2C_1_I2C_MODE_COMPLETE_XFER);
    while (I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_XFER_INP) {}
    I2C_1_I2CMasterClearStatus();
}

static void lcd_pulseer_enable(uint8_t data) {
    lcd_i2c_schrijf_byte(data | LCD_ENABLE);
    CyDelayUs(2u);
    lcd_i2c_schrijf_byte(data & ~LCD_ENABLE);
    CyDelayUs(100u);
}

static void lcd_verstuur_nibble(uint8_t nibble, uint8_t mode) {
    uint8_t data = (nibble & 0xF0u) | mode | LCD_BACKLIGHT;
    lcd_i2c_schrijf_byte(data);
    lcd_pulseer_enable(data);
}

static void lcd_verstuur_byte(uint8_t value, uint8_t mode) {
    lcd_verstuur_nibble(value & 0xF0u, mode);
    lcd_verstuur_nibble((value << 4u) & 0xF0u, mode);
}

void lcd_commando(uint8_t cmd) { lcd_verstuur_byte(cmd, 0x00u); }
void lcd_schrijf_karakter(char c) { lcd_verstuur_byte((uint8_t)c, LCD_RS); }

void lcd_start(void) {
    CyDelay(50u);
    lcd_verstuur_nibble(0x30u, 0x00u); CyDelay(5u);
    lcd_verstuur_nibble(0x30u, 0x00u); CyDelayUs(150u);
    lcd_verstuur_nibble(0x30u, 0x00u);
    lcd_verstuur_nibble(0x20u, 0x00u);
    lcd_commando(0x28u);
    lcd_commando(0x0Cu);
    lcd_commando(0x06u);
    lcd_commando(0x01u);
    CyDelay(2u);
}

void lcd_wissen(void) {
    lcd_commando(0x01u);
    CyDelay(2u);
}

void lcd_zet_cursor(uint8_t kolom, uint8_t rij) {
    const uint8_t offsets[] = {0x00u, 0x40u, 0x14u, 0x54u};
    if (rij > 3) rij = 3; 
    lcd_commando(0x80u | (kolom + offsets[rij]));
}

// Zet tekst perfect in het midden van het scherm
void lcd_print_gecentreerd(uint8_t rij, const char *tekst) {
    uint8_t lengte = strlen(tekst);
    if (lengte > 20) lengte = 20; 
    
    uint8_t spatiesLinks = (20 - lengte) / 2;
    uint8_t spatiesRechts = 20 - lengte - spatiesLinks;

    lcd_zet_cursor(0, rij);
    for (uint8_t i = 0; i < spatiesLinks; i++) lcd_schrijf_karakter(' ');
    for (uint8_t i = 0; i < lengte; i++) lcd_schrijf_karakter(tekst[i]);
    for (uint8_t i = 0; i < spatiesRechts; i++) lcd_schrijf_karakter(' ');
}

/* ========== HARDWARE LEZEN ========== */
static int leesModulePin(int moduleNummer) {
    uint8_t waarde = 0xFFu; 
    switch (moduleNummer) {
        case 0: waarde = Module_0_Read(); break;
        case 1: waarde = Module_1_Read(); break;
        case 2: waarde = Module_2_Read(); break;
        case 3: waarde = Module_3_Read(); break;
        case 4: waarde = Module_4_Read(); break;
        default: break;
    }
    for (int j = 0; j < 5; j++) {
        if ((waarde & (1u << j)) == 0u) return j; // Geeft terug welke plug erin zit (0-4)
    }
    return -1; // Niets ingeplugd
}

/* ========== VARIABELEN ========== */
enum SpelStatus {
    WACHTEN,
    SPELEN,
    OPGELOST
};

static SpelStatus huidigeStatus = WACHTEN;

static int      doelPinnen[5];         // De juiste oplossing
static int      laatstePlugStatus[5];  // Om te onthouden wat er ingeplugd was (voor PuTTY prints)
static uint32_t startTijd        = 0u;
static uint32_t opgelostTijd     = 0u;
static uint32_t laatsteLcdUpdate = 0u; 
static uint32_t laatsteLedBlink  = 0u;
static bool     lcdKnipperStatus = false;

// Willekeurige nummer generator
static uint32_t willekeurig_getal_seed = 0xACE1u;
static uint32_t genereer_willekeurig(void) {
    willekeurig_getal_seed ^= willekeurig_getal_seed << 13u;
    willekeurig_getal_seed ^= willekeurig_getal_seed >> 17u;
    willekeurig_getal_seed ^= willekeurig_getal_seed << 5u;
    return willekeurig_getal_seed;
}

// Deze functie wordt ALLEEN aangeroepen bij de start, nooit tijdens het spelen
static void berekenNieuweCode(void) {
    // 1. Check wat er nu fysiek is ingeplugd
    int huidigePlugs[5];
    for(int i = 0; i < 5; i++) {
        huidigePlugs[i] = leesModulePin(i);
        laatstePlugStatus[i] = huidigePlugs[i]; // Reset seriële tracker
    }

    int posities[5] = {0, 1, 2, 3, 4};
    bool codeIsGoed = false;

    // 2. Blijf codes verzinnen totdat we er één hebben waarbij 0 pinnen kloppen
    while (!codeIsGoed) {
        // Schudden (Shuffle)
        for (int i = 4; i > 0; i--) {
            int j = (int)(genereer_willekeurig() % (uint32_t)(i + 1));
            int tijdelijk = posities[i];
            posities[i] = posities[j];
            posities[j] = tijdelijk;
        }

        // Controleer of de nieuwe code al per ongeluk goed zit
        codeIsGoed = true; 
        for (int i = 0; i < 5; i++) {
            if (huidigePlugs[i] != -1 && posities[i] == huidigePlugs[i]) {
                codeIsGoed = false; // Oeps, deze zat al goed. Opnieuw schudden!
                break; 
            }
        }
    }

    // 3. Sla de code definitief op
    for (int i = 0; i < 5; i++) {
        doelPinnen[i] = posities[i];
    }
    
    // Print oplossing voor de Game Master in PuTTY
    printf("\r\n================================\r\n");
    printf("NIEUWE CODE GEGENEREERD\r\n");
    printf("Anti-Cheat: Precies 0 pinnen zijn nu correct.\r\n");
    for(int i = 0; i < 5; i++) {
        printf("Module %d moet in -> Plug %d\r\n", i, doelPinnen[i]);
    }
    printf("================================\r\n\n");
}

/* ========== STATUS LOGICA ========== */

static void logica_Wachten(void) {
    uint32_t nu = millis_teller;
    RedLED_Write(0u);
    GreenLED_Write(0u);
    Done_Pin_Write(0u);

    // Update LCD rustig (1x per seconde)
    if ((nu - laatsteLcdUpdate) > 1000u) {
        laatsteLcdUpdate = nu;
        lcd_print_gecentreerd(0, ""); 
        lcd_print_gecentreerd(1, "Los andere puzzels");
        lcd_print_gecentreerd(2, "op om te activeren");
        lcd_print_gecentreerd(3, "");
    }

    // Luister naar de ESP32 op pin P0[5]
    if (Activate_Pin_Read() == 1u) {
        CyDelay(50u); // Debounce tegen ruis
        if (Activate_Pin_Read() == 1u) {
            printf("\r\nESP32 Signaal Ontvangen! Puzzel Start...\r\n");
            
            // Extra willekeurigheid gebaseerd op de tijd
            willekeurig_getal_seed ^= millis_teller; 
            
            // Verander status en genereer de code!
            berekenNieuweCode();
            huidigeStatus = SPELEN;
            startTijd = millis_teller; 
            laatsteLedBlink = millis_teller;
        }
    }
}

static void logica_Spelen(void) {
    uint32_t nu = millis_teller;
    uint32_t verstrekenTijd = nu - startTijd;

    // Knipper Rode LED
    if ((nu - laatsteLedBlink) > 500u) {
        RedLED_Write(RedLED_Read() ^ 1u); // Toggle
        laatsteLedBlink = nu;
    }

    int aantalIngeplugd = 0;
    int aantalCorrect   = 0;

    // Controleer de pinnen
    for (int i = 0; i < 5; i++) {
        int gelezenPin = leesModulePin(i);
        
        // Print alleen naar PuTTY als er iets verandert
        if (gelezenPin != laatstePlugStatus[i]) {
            if (gelezenPin != -1) {
                printf("Module %d: Plug %d", i, gelezenPin);
                if (gelezenPin == doelPinnen[i]) printf(" -> CORRECT!\r\n");
                else printf(" -> FOUT! (moet %d zijn)\r\n", doelPinnen[i]);
            } else {
                printf("Module %d: Losgekoppeld.\r\n", i);
            }
            laatstePlugStatus[i] = gelezenPin; 
        }

        // Tellen voor de win-conditie
        if (gelezenPin != -1) {
            aantalIngeplugd++;
            if (gelezenPin == doelPinnen[i]) {
                aantalCorrect++;
            }
        }
    }

    // CHECK OF WE HEBBEN GEWONNEN
    if (aantalIngeplugd == 5 && aantalCorrect == 5) {
        printf("\r\n*** PUZZEL OPGELOST! ***\r\n");
        huidigeStatus = OPGELOST;
        opgelostTijd  = nu;
        
        Done_Pin_Write(1u); // Geef signaal aan de volgende puzzel!
        RedLED_Write(0u);
        GreenLED_Write(1u);
        return; 
    }

    // LCD UPDATE LOGICA (maximaal 5x per seconde om scherm stabiel te houden)
    if ((nu - laatsteLcdUpdate) > 200u) {
        laatsteLcdUpdate = nu;

        if (verstrekenTijd < 10000u) {
            // Fase 1: Knipperend Welkom (0 - 10 sec)
            if ((verstrekenTijd % 1000u) < 500u) {
                lcd_print_gecentreerd(0, "");
                lcd_print_gecentreerd(1, "Welkom bij de");
                lcd_print_gecentreerd(2, "ethernet puzzel");
                lcd_print_gecentreerd(3, "");
            } else {
                lcd_print_gecentreerd(0, "");
                lcd_print_gecentreerd(1, "");
                lcd_print_gecentreerd(2, "");
                lcd_print_gecentreerd(3, "");
            }
        } 
        else if (verstrekenTijd < 20000u) {
            // Fase 2: Vast Welkom (10 - 20 sec)
            lcd_print_gecentreerd(0, "");
            lcd_print_gecentreerd(1, "Welkom bij de");
            lcd_print_gecentreerd(2, "ethernet puzzel");
            lcd_print_gecentreerd(3, "");
        } 
        else if (verstrekenTijd < 25000u) {
            // Fase 3: Instructie (20 - 25 sec)
            lcd_print_gecentreerd(0, "");
            lcd_print_gecentreerd(1, "Steek alle plugs in");
            lcd_print_gecentreerd(2, "de juiste volgorde");
            lcd_print_gecentreerd(3, "");
        } 
        else {
            // Fase 4: Spel spelen (> 25 sec)
            if (aantalIngeplugd < 5) {
                lcd_print_gecentreerd(0, "");
                lcd_print_gecentreerd(1, "Steek alle plugs in");
                lcd_print_gecentreerd(2, "de juiste volgorde");
                lcd_print_gecentreerd(3, "");
            } else {
                char tekstBuffer[21]; 
                if (aantalCorrect == 1) {
                    snprintf(tekstBuffer, sizeof(tekstBuffer), "1 is correct");
                } else {
                    snprintf(tekstBuffer, sizeof(tekstBuffer), "%d zijn correct", aantalCorrect);
                }
                lcd_print_gecentreerd(0, "");
                lcd_print_gecentreerd(1, tekstBuffer);
                lcd_print_gecentreerd(2, "probeer nog eens");
                lcd_print_gecentreerd(3, "");
            }
        }
    }
}

static void logica_Opgelost(void) {
    uint32_t nu = millis_teller;
    
    // Knipper het LCD scherm om overwinning te vieren
    if ((nu - laatsteLcdUpdate) > 400u) {
        lcdKnipperStatus = !lcdKnipperStatus;
        if (lcdKnipperStatus) {
            lcd_print_gecentreerd(0, "");
            lcd_print_gecentreerd(1, "ALLES JUIST!!!");
            lcd_print_gecentreerd(2, "!!!!!!!!!!!!!!!!");
            lcd_print_gecentreerd(3, "");
        } else {
            lcd_print_gecentreerd(0, "");
            lcd_print_gecentreerd(1, "");
            lcd_print_gecentreerd(2, "");
            lcd_print_gecentreerd(3, "");
        }
        laatsteLcdUpdate = nu;
    }

    // AUTO-RESET: Ga na 30 seconden terug naar WACHTEN status
    if ((nu - opgelostTijd) > 30000u) {
        printf("\r\n--- Puzzel is gereset (30 seconden voorbij) ---\r\n");
        huidigeStatus = WACHTEN;
    }
}

/* ========== MAIN ========== */
int main(void) {
    CyGlobalIntEnable;
    
    // Start de milliseconde timer
    CySysTickStart();
    CySysTickSetCallback(0u, SysTick_Handler);
    CySysTickSetReload(48000u - 1u);
    
    UART_Start();
    printf("\r\n\r\n--- SYSTEEM OPGESTART ---\r\n");

    I2C_1_Start();
    lcd_start();

    // Zet beginstatus
    willekeurig_getal_seed = millis_teller ^ 0xDEADBEEFu;
    huidigeStatus = WACHTEN;
    laatsteLcdUpdate = 0u;

    // Oneindige loop
    for (;;) {
        switch(huidigeStatus) {
            case WACHTEN: 
                logica_Wachten(); 
                break;
            case SPELEN:  
                logica_Spelen();  
                break;
            case OPGELOST:  
                logica_Opgelost();  
                break;
        }
    }
}